## Chapter 10. Exceptions（异常）

### Chapter 10 Introduction（章节介绍）

WHEN used to best advantage, exceptions can improve a program’s readability, reliability, and maintainability. When used improperly, they can have the opposite effect. This chapter provides guidelines for using exceptions effectively.
