## Chapter 9. General Programming（泛型编程）

### Chapter 9 Introduction（章节介绍）

THIS chapter is devoted to the nuts and bolts of the language. It discusses local variables, control structures, libraries, data types, and two extralinguistic facilities: reflection and native methods. Finally, it discusses optimization and naming conventions.
